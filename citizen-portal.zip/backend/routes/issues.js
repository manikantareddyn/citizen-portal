const express = require('express');
const multer = require('multer');
const Issue = require('../models/Issue');

const router = express.Router();
const upload = multer({ dest: 'uploads/' });

router.post('/', upload.single('file'), async (req, res) => {
  const { description } = req.body;
  const file = req.file.path;

  const issue = new Issue({ description, file });
  await issue.save();
  res.status(201).send(issue);
});

module.exports = router;
