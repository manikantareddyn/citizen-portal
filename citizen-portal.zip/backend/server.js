const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const issueRoutes = require('./routes/issues');
const dataRoutes = require('./routes/data');

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

app.use('/api/issues', issueRoutes);
app.use('/api/data', dataRoutes);

mongoose.connect('mongodb://localhost:27017/citizen-portal', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
