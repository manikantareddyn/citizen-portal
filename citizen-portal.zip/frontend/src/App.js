import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import ReportIssue from './pages/ReportIssue';
import CityServices from './pages/CityServices';
import RealTimeData from './pages/RealTimeData';

const App = () => (
  <Router>
    <Navbar />
    <Switch>
      <Route exact path="/" component={Home} />
      <Route path="/report-issue" component={ReportIssue} />
      <Route path="/city-services" component={CityServices} />
      <Route path="/real-time-data" component={RealTimeData} />
    </Switch>
  </Router>
);

export default App;
