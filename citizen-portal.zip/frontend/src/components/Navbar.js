import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => (
  <nav>
    <ul>
      <li><Link to="/">Home</Link></li>
      <li><Link to="/report-issue">Report Issue</Link></li>
      <li><Link to="/city-services">City Services</Link></li>
      <li><Link to="/real-time-data">Real-Time Data</Link></li>
    </ul>
  </nav>
);

export default Navbar;
