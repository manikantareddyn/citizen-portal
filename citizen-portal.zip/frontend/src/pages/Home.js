import React from 'react';

const Home = () => (
  <div>
    <h1>Welcome to the City Portal</h1>
  </div>
);

export default Home;
