import React, { useState } from 'react';
import axios from 'axios';

const ReportIssue = () => {
  const [description, setDescription] = useState('');
  const [file, setFile] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('description', description);
    formData.append('file', file);

    await axios.post('http://localhost:5000/api/issues', formData);
  };

  return (
    <div>
      <h1>Report an Issue</h1>
      <form onSubmit={handleSubmit}>
        <textarea 
          value={description} 
          onChange={(e) => setDescription(e.target.value)} 
          placeholder="Describe the issue"
        />
        <input 
          type="file" 
          onChange={(e) => setFile(e.target.files[0])} 
        />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default ReportIssue;
